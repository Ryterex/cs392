# hw4cs392
homework about transposing matrices using locality
