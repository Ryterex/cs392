#ifndef OOCMERGE_H_
#define OOCMERGE_H_
#endif

void mergeeven( int number, char files[number][16]);
int verify(char * output);
void deleteALL(int N);
